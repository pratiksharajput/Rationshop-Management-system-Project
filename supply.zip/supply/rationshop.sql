-- phpMyAdmin SQL Dump
-- version 2.11.2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 28, 2015 at 11:30 AM
-- Server version: 5.0.45
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `rationshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `cardregister`
--

CREATE TABLE `cardregister` (
  `name` varchar(30) NOT NULL,
  `address` varchar(60) NOT NULL,
  `cntno` varchar(30) NOT NULL,
  `idate` varchar(30) NOT NULL,
  `ctype` varchar(30) NOT NULL,
  `cno` varchar(30) NOT NULL,
  `occupation` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cardregister`
--

INSERT INTO `cardregister` (`name`, `address`, `cntno`, `idate`, `ctype`, `cno`, `occupation`) VALUES
('Dilip Pahuna Bhagirath.', 'Behind Church adarsha Nagar,Malegaon', '8275582317', '2016-01-03', 'Orange', '1005', 'L I C Agent'),
('Tukaram  Pundlik Nikam', 'Behind Church Ram nagar.Malegaon camp', '8605945591', '2016-05-17', 'Yellow', '1015', 'Teacher'),
('Narayansingh Budhasingh Rajput', 'Behind PWD Office ,malegaon Camp.', '9823752174', '2016-02-09', 'White', '1016', 'Police'),
('Deepak Mansing Nikam', 'Roze,Malegaon', '9637507804', '2016-09-12', 'Orange', '1020', 'Farmer'),
('Yogesh Khandu  Wankhede', 'Ram nagari,malegaon camp.', '9975830601', '2016-10-11', 'Orange', '1025', 'Teacher'),
('Vijay Bhagwat Sawkare.', 'Adarsha nagar,malegaon camp.', '8605430599', '2016-03-02', 'Yellow', '1030', 'Teacher'),
('Rajendra Ratan Pawar.', 'pranya colony,malegaon camp.', '9856742356', '2016-04-06', 'Yellow', '1035', 'Employee'),
('Shubham Dilip bhagirath.', 'Behind Church ,malegaon camp', '9856321478', '2016-05-11', 'Orange', '1040', 'Employee'),
('Gopal Pundlik nikam', 'Malegaon Camp.', '8896541237', '2016-05-11', 'Orange', '1045', 'Teacher'),
('Suresh Thosare.', 'Ekta nagar ,malegaon camp.', '8956741236', '2016-06-02', 'Yellow', '1046', 'Employee'),
('Pradip mansing Rajput.', 'Malegaon camp.', '7789562314', '2016-08-10', 'Yellow', '1050', 'Farmer'),
('Kunal Narayan Rajput.', 'PWD office ,Malegaon Camp', '7789562314', '2016-10-05', 'White', '1055', 'Employee'),
('Prafull  Namdev Nikam.', 'Pragati colony,Malegaon camp.', '9865321478', '2016-12-07', 'Yellow', '1060', 'Teacher'),
('Ketan Pradip Patil.', 'Shikshak colony ,Malegaon Camp.', '8956231478', '2015-10-07', 'Yellow', '1065', 'Employee'),
('Laxman Patil.', 'Ekta colony,Malegaon camp.', '8956231478', '2015-12-23', 'Orange', '1067', 'Employee'),
('Narayan Chaudhari.', 'Adarsha Nagar,malegaon camp.', '7789562314', '2015-10-14', 'White', '1054', 'Teacher'),
('Subhash Shirsath.', 'Maleria colony,Malegaon Camp.', '9865321478', '2016-09-08', 'Yellow', '1034', 'Teacher'),
('Sunil Nikam', 'Navvasath,Malegaon Camp.', '7789654123', '2016-02-09', 'Yellow', '1048', 'Employee'),
('Lucky rajendra Pawar', 'Malegaon camp', '8963125478', '2016-9-6', 'Orange', '1001', 'employee');

-- --------------------------------------------------------

--
-- Table structure for table `changepassword`
--

CREATE TABLE `changepassword` (
  `uname` varchar(30) NOT NULL,
  `passw` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `changepassword`
--

INSERT INTO `changepassword` (`uname`, `passw`) VALUES
('rshop123', 'rshop123');

-- --------------------------------------------------------

--
-- Table structure for table `createuser`
--

CREATE TABLE `createuser` (
  `name` varchar(30) NOT NULL,
  `address` varchar(60) NOT NULL,
  `cntno` varchar(30) NOT NULL,
  `uname` varchar(30) NOT NULL,
  `passw` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `createuser`
--

INSERT INTO `createuser` (`name`, `address`, `cntno`, `uname`, `passw`) VALUES
('Pratiksha narayan rajput', 'prerna society,malegaon.', '7040243727', 'pratiksha123', 'pratiksha123'),
('Megha dilip bhagirath', 'adarsh society,malegaon camp,malegaon. ', '9975830601', 'megha123', 'megha123'),
('Diksha tukaram nikam', 'ram nagari,malegaon', '8605945591', 'diksha123', 'diksha123');

-- --------------------------------------------------------

--
-- Table structure for table `dailyrecord`
--

CREATE TABLE `dailyrecord` (
  `cno` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL,
  `wheat` varchar(30) NOT NULL,
  `rice` varchar(30) NOT NULL,
  `sugar` varchar(30) NOT NULL,
  `oil` varchar(30) NOT NULL,
  `kerosene` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dailyrecord`
--

INSERT INTO `dailyrecord` (`cno`, `name`, `date`, `wheat`, `rice`, `sugar`, `oil`, `kerosene`) VALUES
('1050', 'Pradip mansing Rajput.    ', '2016-03-09', '10', '20', '10', '5', '5'),
('1005', 'Dilip Pahuna Bhagirath.    ', '2016-01-01', '10', '10', '20', '5', '5'),
('1015', 'Tukaram  Pundlik Nikam    ', '2016-01-01', '10', '10', '10', '5', '5'),
('1016', 'Narayansingh Budhasingh Rajput', '2016-02-16', '15', '15', '10', '5', '5'),
('1020', 'Deepak Mansing Nikam    ', '2016-02-18', '10', '10', '10', '5', '5'),
('1025', 'Yogesh Khandu  Wankhede    ', '2016-02-18', '10', '10', '10', '5', '5'),
('1030', 'Vijay Bhagwat Sawkare.    ', '2016-03-11', '10', '10', '10', '5', '5'),
('1040', 'Shubham Dilip bhagirath.    ', '2016-03-22', '10', '10', '10', '5', '5'),
('1045', 'Gopal Pundlik nikam    ', '2016-04-09', '10', '10', '10', '5', '5'),
('1046', 'Suresh Thosare.    ', '2016-04-09', '10', '10', '10', '5', '5'),
('1050', 'Pradip mansing Rajput.    ', '2016-04-09', '10', '10', '10', '5', '5'),
('1055', 'Kunal Narayan Rajput.    ', '2016-04-13', '10', '10', '10', '5', '5'),
('1060', 'Prafull  Namdev Nikam.    ', '2016-05-16', '15', '10', '10', '5', '5'),
('1065', 'Ketan Pradip Patil.    ', '2016-05-18', '15', '10', '10', '5', '5'),
('1035', 'Rajendra Ratan Pawar.    ', '2016-05-16', '10', '10', '15', '5', '10'),
('1054', 'Narayan Chaudhari.    ', '2016-06-15', '15', '10', '10', '5', '5'),
('1034', 'Subhash Shirsath.    ', '2016-06-23', '15', '10', '15', '10', '10'),
('1005', 'Dilip Pahuna Bhagirath.    ', '2016-03-23', '15', '10', '10', '5', '5'),
('1015', 'Tukaram  Pundlik Nikam    ', '2016-06-23', '10', '15', '10', '5', '10'),
('1040', 'Shubham Dilip bhagirath.    ', '2016-03-23', '10', '15', '15', '5', '5'),
('1034', 'Subhash Shirsath.    ', '2016-03-24', '10', '15', '15', '5', '10'),
('1005', 'Dilip Pahuna Bhagirath.    ', '2016-07-18', '10', '15', '15', '10', '10'),
('1016', 'Narayansingh Budhasingh Rajput', '2016-07-18', '10', '15', '10', '10', '15'),
('1040', 'Shubham Dilip bhagirath.    ', '2016-07-19', '10', '15', '10', '5', '10'),
('1050', 'Pradip mansing Rajput.    ', '2016-07-20', '10', '15', '10', '5', '5'),
('1030', 'Gopal Pundlik nikam    ', '2016-07-23', '15', '10', '15', '', '5'),
('1020', 'Deepak Mansing Nikam    ', '2016-07-23', '15', '15', '10', '', '5'),
('1020', 'Deepak Mansing Nikam    ', '2016-08-22', '7', '8', '10', '5', ''),
('1030', 'Vijay Bhagwat Sawkare.    ', '2016-08-23', '8', '5', '5', '5', '5'),
('1040', 'Shubham Dilip bhagirath.    ', '2016-08-20', '10', '8', '6', '5', ''),
('1045', 'Gopal Pundlik nikam    ', '2016-08-20', '9', '4', '5', '', ''),
('1050', 'Pradip mansing Rajput.    ', '2016-08-20', '10', '5', '5', '', '5'),
('1015', 'Tukaram  Pundlik Nikam    ', '2016-08-20', '7', '8', '10', '3', '2'),
('1020', 'Deepak Mansing Nikam    ', '2016-08-20', '6', '5', '8', '', ''),
('1030', 'Vijay Bhagwat Sawkare.    ', '2016-08-20', '8', '6', '8', '', '4'),
('1005', 'Dilip Pahuna Bhagirath.    ', '2016-09-14', '7', '8', '5', '', '3'),
('1015', 'Tukaram  Pundlik Nikam    ', '2016-09-15', '5', '8', '4', '3', ''),
('1040', 'Shubham Dilip bhagirath.    ', '2016-09-15', '10', '5', '4', '3', ''),
('1035', 'Rajendra Ratan Pawar.    ', '2016-09-15', '8', '5', '7', '3', '3'),
('1055', 'Kunal Narayan Rajput.    ', '2016-09-15', '8', '8', '5', '3', '3'),
('1034', 'Subhash Shirsath.    ', '2016-09-15', '8', '5', '8', '3', '3'),
('1048', 'Sunil Nikam    ', '2016-09-15', '8', '8', '5', '3', ''),
('1050', 'Pradip mansing Rajput.    ', '2016-09-15', '10', '7', '7', '3', ''),
('1016', 'Narayansingh Budhasingh Rajput', '2016-09-20', '8', '5', '4', '3', ''),
('1005', 'Dilip Pahuna Bhagirath.    ', '2016-03-15', '8', '9', '4', '3', ''),
('1048', 'Sunil Nikam    ', '2016-10-15', '8', '4', '5', '', '3'),
('1020', 'Deepak Mansing Nikam    ', '2016-10-15', '8', '5', '8', '3', '3'),
('1025', 'Yogesh Khandu  Wankhede    ', '2016-10-15', '10', '8', '9', '', '3'),
('1035', 'Rajendra Ratan Pawar.    ', '2016-10-15', '7', '8', '8', '3', '5'),
('1040', 'Shubham Dilip bhagirath.    ', '2016-10-15', '7', '8', '7', '3', '3'),
('1050', 'Pradip mansing Rajput.    ', '2016-10-15', '10', '7', '8', '3', '2'),
('1055', 'Kunal Narayan Rajput.    ', '2016-10-18', '8', '7', '8', '2', '3'),
('1055', 'Kunal Narayan Rajput.    ', '2016-10-18', '10', '8', '7', '3', ''),
('1055', 'Kunal Narayan Rajput.    ', '2016-11-18', '10', '8', '7', '5', '3'),
('1005', 'Dilip Pahuna Bhagirath.    ', '2016-11-18', '10', '8', '8', '5', '3'),
('1060', 'Prafull  Namdev Nikam.    ', '2016-11-18', '10', '4', '8', '3', '3'),
('1065', 'Ketan Pradip Patil.    ', '2016-11-18', '7', '8', '7', '5', '5'),
('1030', 'Vijay Bhagwat Sawkare.    ', '2016-11-18', '8', '5', '5', '3', '2'),
('1035', 'Rajendra Ratan Pawar.    ', '2016-11-18', '8', '8', '7', '3', '3'),
('1005', 'Dilip Pahuna Bhagirath.    ', '2017-12-16', '10', '8', '8', '3', '3'),
('1025', 'Yogesh Khandu  Wankhede    ', '2016-12-16', '10', '8', '7', '3', '3'),
('1030', 'Vijay Bhagwat Sawkare.    ', '2016-12-16', '8', '6', '4', '3', ''),
('1060', 'Prafull  Namdev Nikam.    ', '2016-12-16', '10', '8', '7', '3', ''),
('1045', 'Gopal Pundlik nikam    ', '2016-12-16', '7', '5', '7', '3', '2'),
('1054', 'Narayan Chaudhari.    ', '2016-12-16', '10', '8', '7', '3', ''),
('1034', 'Subhash Shirsath.    ', '2016-12-16', '10', '8', '7', '3', ''),
('1005', 'Dilip Pahuna Bhagirath.    ', '2016-5-6', '5', '5', '3', '4', '7'),
('1015', 'Tukaram  Pundlik Nikam    ', '2016-10-5', '5', '4', '5', '4', '5'),
('1025', 'Yogesh Khandu  Wankhede    ', '2016-5-5', '2', '5', '8', '4', '2'),
('1060', 'Prafull  Namdev Nikam.    ', '2016-06-06', '5', '5', '5', '5', '5'),
('1025', 'Yogesh Khandu  Wankhede    ', '2016-06-06', '6', '5', '4', '3', '8'),
('1030', 'Vijay Bhagwat Sawkare.    ', '2015-12-05', '5', '1', '3', '8', '3'),
('1001', 'Lucky rajendra Pawar    ', '2012-12-05', '6', '6', '6', '6', '6'),
('1055', 'Kunal Narayan Rajput.    ', '2016-5-06', '5', '6', '4', '9', '6'),
('1067', 'Laxman Patil.    ', '2015-12-12', '4', '6', '3', '4', '5'),
('1001', 'Lucky rajendra Pawar    ', '2016-6-06-05', '5', '5', '3', '3', '3');

-- --------------------------------------------------------

--
-- Table structure for table `providedstock`
--

CREATE TABLE `providedstock` (
  `month` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL,
  `wheat` varchar(30) NOT NULL,
  `rice` varchar(30) NOT NULL,
  `sugar` varchar(30) NOT NULL,
  `oil` varchar(30) NOT NULL,
  `kerosene` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `providedstock`
--

INSERT INTO `providedstock` (`month`, `date`, `wheat`, `rice`, `sugar`, `oil`, `kerosene`) VALUES
('1', '2016-01-01', '500', '350', '360', '200', '100'),
('2', '2016-02-16', '400', '350', '450', '50', '100'),
('3', '2016-03-10', '400', '500', '500', '100', '100'),
('4', '2016-04-09', '550', '450', '500', '150', '100'),
('5', '2016-05-14', '500', '450', '500', '50', '100'),
('6', '2016-06-11', '400', '500', '400', '50', '100'),
('6', '2016-06-15', '500', '400', '400', '100', '100'),
('7', '2016-07-15', '500', '400', '450', '100', '50'),
('8', '2016-08-20', '400', '500', '400', '50', '100'),
('9', '2016-09-14', '350', '400', '400', '50', '50'),
('10', '2016-10-15', '400', '500', '400', '100', '50'),
('11', '2016-11-18', '500', '400', '400', '50', '50'),
('12', '2016-12-16', '500', '400', '400', '100', '100'),
('12', '2016-12-25', '60', '60', '58', '87', '85');
