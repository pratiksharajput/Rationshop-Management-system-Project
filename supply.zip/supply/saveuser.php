<?php
   $name=$_GET['name'];
   $address=$_GET['address'];
   $cntno=$_GET['cntno'];
   $uname=$_GET['uname'];
   $passw=$_GET['passw'];
   
   $con=mysql_connect("localhost","root","");
   mysql_select_db("rationshop",$con);
   $sql="insert into createuser values('$name','$address','$cntno','$uname','$passw')";
   $result=mysql_query($sql);
   if($result==1)
   echo "Record is Saved";
   else
   echo "Record is not Saved";
?>   
 