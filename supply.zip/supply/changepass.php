<?php
  
   $uname=$_GET['uname'];
   $passw=$_GET['passw'];
   
   $con=mysql_connect("localhost","root","");
   mysql_select_db("rationshop",$con);
    
   $sql="UPDATE changepassword SET uname='$uname',passw='$passw'where 1";
   $result=mysql_query($sql);
   if($result==1)
   echo "Password is Saved";
   else
   echo "Password is not Saved";
?>   
 