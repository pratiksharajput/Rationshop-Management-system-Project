<html>
<head>
       <link rel="stylesheet" href="./css/bootstrap.css">
       <script type="text/javascript" src="./js/jquery.js"></script>
       <script type="text/javascript" src="./js/bootstrap.min.js"></script>  
       
       <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>Ration Shop Management System</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
        
    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]--> 

       <script type="text/javascript">
          $(document).ready(function () {
            $("#exit").click(function () {
                 window.location="demo.php";
           });
          });
       </script>
       <script type="text/javascript">
          $(document).ready(function () {
            $("#save").click(function () {
               var name = $("#name").val();
               var address=$("#address").val();
               var cntno=$("#cntno").val();
               var idate=$("#idate").val();
               var ctype=$("#ctype").val();
               var cno=$("#cno").val();
               var occuption=$("#occuption").val();
               var data1="name="+name+"&address="+address+"&cntno="+cntno+"&idate="+idate+"&ctype="+ctype+"&cno="+cno+"&occuption="+occuption;
               var flag=0; 
       if (name == '') 
       {
         alert("Name should not empty");
         flag=1;
         $("#name").focus();  
       }
       if (address== '') 
       {
         alert("Address should not empty");
         flag=1;
         $("#address").focus();  
       }
       if (cntno== '') 
       {
         alert("Contact no should not empty");
         flag=1;
         $("#cntno").focus();  
       }
       if (ctype== '') 
       {
         alert("Card type should not empty");
         flag=1;
         $("#ctype").focus();  
       }
       if (cno== '') 
       {
        alert("Card no should not empty");
         flag=1;
         $("#cno").focus();  
       }
        
       if(flag==0)
        {
               $.ajax({
                            url:"savecard.php",
                            data:data1,
                            success: function(result){
                                alert(result);
                              $("#name").val("");
                              $("#address").val("");
                              $("#cntno").val("");
                              $("#idate").val("");
                              $("#ctype").val("");
                              $("#cno").val("");
                              $("#occuption").val("");

                            } 
              });
         }
            });
         });
       </script>
    </head>
<BODY>

<DIV class="container">
<DIV class="row">

<!--header start-->
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <!--logo start-->
            <a class="logo"><font color=black><b>Card Register</b></a>
            <!--logo end-->
            
            <div class="top-menu">
               <br>
            	<ul class="nav pull-right top-menu">
                    <li><a class="home" href="demo.php">Home</a></li>
            	</ul>
            </div>
        </header>
      <!--header end-->

<DIV class="COL-SM-3">
</DIV>

<DIV class="COL-SM-6"><font color=black><br><br><br>

<FORM class="form-horizontal" role="form">
  
         
      <div class="form-group">
      <div class="col-sm-2">         
      </div>
      <div class="col-sm-10">
      
      </div>   
      </div>
      <div class="form-group">
      <h4><label class="control-label col-sm-4" for="Name">Name:-</label></h4>
      <div class="col-sm-8">
      <input type="text" class="form-control" id="name">
      </div>
      </div><br>
      
      <div class="form-group">
       <h4><label class="control-label col-sm-4 " for="add">Address:-</label></h4>
      <div class="col-sm-8">
      <TEXTAREA width=300 height=400 name=Address class="form-control" id="address" ></TEXTAREA>
      </div>
      </div><br>
      <div class="form-group">
      <h4><label class="control-label col-sm-4" for="Cno">Contact No:-</label></h4>
       <div class="col-sm-8">
      <input type="text" class="form-control" id="cntno">
      </div>
      </div><br>
       
      <div class="form-group">
      <h4><label class="control-label  col-sm-4" for="IDate" >Issue Date:-</label></h4>
      <div class="col-sm-8">
       <input type="date" class="form-control" id="idate">
      </div>
      </div><br>
      
      <div class="form-group">
      <h4><label class="control-label  col-sm-4" for="ctype">Card Type:-</label></h4>
      <div class="col-sm-8">
       <select name="cardtype" class="form-control" id="ctype">
       <option value="Orange">Orange</option>
       <option value="Yellow">Yellow</option>
       <option value="White">White</option>
      </select>
      </div>
      </div><br>
      
      <div class="form-group">
      <h4><label class="control-label col-sm-4" for="cno">Card No:-</label></h4>
      <div class="col-sm-8">
      <input type="text" class="form-control" id="cno">
      </div>
      </div><br>
       
      <div class="form-group">
       <h4><label class="control-label col-sm-4 " for="occ">Occupation:-</label></h4>
      <div class="col-sm-8">
      <input type="text" class="form-control" id="occuption">
      </div>
      </div><br>

      <div class="form-group">
      <div class="col-sm-4">         
      </div>
      
      <div class="col-sm-8">
      
      <div class="col-sm-6">
      <b><input type=button class="btn btn-Info btn-block" id="save" value="Save"></b>
      </div>      
      <div class="col-sm-6">
      <input type=button class="btn btn-Info btn-block" id="exit" value="Exit">
      </div>
      </div>
      
</div>
  
  
</FORM>
</DIV>

<DIV class="COL-SM-3">
</DIV>

</DIV>
</DIV>
</body>
</html>
