<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>Ration Shop Management System</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
        
    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

  <section id="container" >
      <!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT & NOTIFICATIONS
      *********************************************************************************************************************************************************** -->
      <!--header start-->
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <!--logo start-->
            <a class="logo"><b>Ration Shop Management System</b></a>
            <!--logo end-->
            
            <div class="top-menu">
            	<ul class="nav pull-right top-menu">
                    <li><a class="logout" href="Index.php">Logout</a></li>
            	</ul>
            </div>
        </header>
      <!--header end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN SIDEBAR MENU
      *********************************************************************************************************************************************************** -->
      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">
              
              	  <p class="centered"><a href="images/20151123134809.jpg"><img src="images/20151123165045.jpg" class="img-square" width="150"></a></p>
              	  <h5 class="centered">Ration Shop</h5>
              	  	
                  
                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-desktop"></i>
                          <span>Tasks</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="searchr.php">Search</a></li>
                          <li><a  href="cardregister.php">Register</a></li>
                          <li><a  href="deleter.php">Delete</a></li>
                          <li><a  href="astock.php">Available Stock</a></li>
                          <li><a  href="pstock.php">Provided Stock</a></li>
                      </ul>
                  </li>

                  
                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-book"></i>
                          <span>Report</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="show.php">Stock Wise</a></li>
                          <li><a  href="custreport.php">Customer Wise</a></li>
                      </ul>
                  </li>

                     <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-cogs"></i>
                          <span>Setting</span>
                      </a>
                      <ul class="sub">
                           <li><a  href="showcardregister.php">Show Register Card</a></li>
                          <li><a  href="createUser.php">Create User</a></li>
                          <li><a  href="confirmpass.php">Change Password</a></li>
                          
                     </ul>
                  </li>
                      
                   <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-tasks"></i>
                          <span>License</span>
                      </a>
                      <ul class="sub">
   
                          <li><a  href="license.php">Show License</a></li>
                          
                     </ul>
                  </li>
           
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
<div class="container">
     <div class="jumbotron"><BR>
       <h2>Ration Shop Management System</h2><BR><BR>      
        <p>Online Ration Shop Management System is a Web based computer
           management system which is useful to maintain records of 
           Ration Shop system.Customer is important asset of the organisation.
           Hence to maintain this asset,their satisfaction is verly important.
           While maintaining the accuracy in records this system is very helpful.  </p>
        </div><BR>
           <p align=center>Copyright &copy 2016 Ration Shop Managemnt System Developed by :</p> 
           <p align=center>Name1:Pratiksha Rajput</p>     
           <p align=center>Name2:Megha Bhagirath</p>
           <p align=center>Name3:   Diksha Nikam</p>
      
   </div>

          	
                      

		</section><! --/wrapper -->
      </section><!-- /MAIN CONTENT -->

      <!--main content end-->
     
      <!--footer end-->
  </section>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>


    <!--common script for all pages-->
    <script src="assets/js/common-scripts.js"></script>

    <!--script for this page-->
    
  <script>
      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>
