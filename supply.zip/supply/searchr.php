<html>
<head>
<link rel="stylesheet" href="./css/bootstrap.min.css">
  <script src="./js/jquery.js"></script>
  <script src="./js/bootstrap.min.js"></script>

<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>Ration Shop Management System</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
        
    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->  

  <script type="text/javascript">
          $(document).ready(function () {
            $("#exit").click(function () {
                 window.location="demo.php";
           });
          });
       </script>
  <script type="text/javascript">
          $(document).ready(function () {
            $("#search").click(function () {
               var cno = $("#cno").val();
          
               var data1="&cno="+cno;
               var flag=0; 
       
       
               $.ajax({
                            url:"searchname.php",
                            data:data1,
                            success: function(result){
                                
                              $("#name").val(result);
                                                          } 
              });
         
            });
         });
       </script>

    <script type="text/javascript">
          $(document).ready(function () {
            $("#save").click(function () {
               var cno=$("#cno").val();
               var name=$("#name").val();
               var date=$("#date").val();
               var wheat=$("#wheat").val();
               var rice=$("#rice").val();
               var sugar=$("#sugar").val();
               var oil=$("#oil").val();
               var kerosene=$("#kerosene").val();
               var data1="&cno="+cno+"&name="+name+"&date="+date+"&wheat="+wheat+"&rice="+rice+"&sugar="+sugar+"&oil="+oil+"&kerosene="+kerosene;
       


               $.ajax({
                            url:"savesearch.php",
                            data:data1,
                            success: function(result){
                                alert(result);
                                 $("#cno").val("");
                                $("#name").val("");
                              $("#date").val("");
                              $("#wheat").val("");
                              $("#rice").val("");
                              $("#sugar").val("");
                              $("#oil").val("");
                              $("#kerosene").val("");
                                $("#amount").val("");
                            } 
              });
         
            });
         });
       </script>

     <script type="text/javascript">
          $(document).ready(function () {
            $("#calculate").click(function () {
               
               var wheat=$("#wheat").val();
               var rice=$("#rice").val();
               var sugar=$("#sugar").val();
               var oil=$("#oil").val();
               var kerosene=$("#kerosene").val();
               var data1="&wheat="+wheat+"&rice="+rice+"&sugar="+sugar+"&oil="+oil+"&kerosene="+kerosene;
       


               $.ajax({
                            url:"calculate.php",
                            data:data1,
                            success: function(result){
                                
                               
                              $("#amount").val(result);
                              

                            } 
              });
         
            });
         });
       </script>

    
</head>
<BODY>

<!--......Search form...-->

<DIV class="container">
<DIV class="row">

<!--header start-->
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <!--logo start-->
            <a class="logo"><font color=black><b>Place Order</b></a>
            <!--logo end-->
            
            <div class="top-menu">
                <br>
            	<ul class="nav pull-right top-menu">
                    <li><a class="home" href="demo.php">Home</a></li>
            	</ul>
            </div>
        </header>
      <!--header end-->

<DIV class="COL-SM-3">
</div>


<DIV CLASS="COL-SM-6" ><font color=black><br><br>
 
<FORM method=GET action="bill.php"  class="form-horizontal" role="form">

<FORM class="form-horizontal" role="form">

         
    <div class="form-group"><br><br>
    <h4><label class="control-label col-sm-4" for="cno"><b>Card No:</b></label></h4>
    <div class="col-sm-8">
    <input type="text" class="form-control" id="cno" name="cno" >
     </div><br><br><br>
    </div>

    <div class="form-group"> 
    <div class="col-sm-offset-6 col-sm-8">
   <input type=button class="btn btn-Info " id="search" value="Search">
    </div><br><br><br>
    </div>

    <div class="form-group">
    <h4><label class="control-label col-sm-4" for="name"><b>Name:</b></label></h4>
    <div class="col-sm-8">
    <input type="text" class="form-control" id="name" name="name">
     </div><br><br><br>
    </div>

    <div class="form-group">
      <h4><label class="control-label  col-sm-4" for="date"><b>Date:-</b></label></h4>
      <div class="col-sm-8">
       <input type="date" class="form-control" id="date" name="date">
      </div><br><br><br>
      </div>

    <div class="form-group">
    <h4><label class="control-label col-sm-4" for="wheat"><b>Wheat:</b></label></h4>
    <div class="col-sm-8">
    <input type="text" class="form-control" placeholder="kg" id="wheat" name="wheat" >
     </div>
    </div><br><br>

    <div class="form-group">
    <h4><label class="control-label col-sm-4" for="rice"><b>Rice:</b></label></h4>
    <div class="col-sm-8">
    <input type="text" class="form-control" placeholder="kg" id="rice" name="rice" >
    </div>
    </div><br><br>


    <div class="form-group">
    <h4><label class="control-label col-sm-4" for="sugar"><b>Sugar:</b></label></h4>
    <div class="col-sm-8">
    <input type="text" class="form-control" placeholder="kg" id="sugar" name="sugar">
    </div>
    </div><br><br>

    <div class="form-group">
    <h4><label class="control-label col-sm-4" for="oil"><b>Oil:</b></label></h4>
    <div class="col-sm-8">
    <input type="text" class="form-control" placeholder="lit" id="oil" name="oil">
    </div>
    </div><br><br>

    <div class="form-group">
    <h4><label class="control-label col-sm-4" for="kerosene"><b>Kerosene:</b></label></h4>
    <div class="col-sm-8">
    <input type="text" class="form-control" placeholder="lit" id="kerosene" name="kerosene">
    </div>
    </div><br><br>


   <div class="form-group">
<div class="col-sm-6">
</div>
<div class="col-sm-6">
<button type=button class="btn btn-Info btn-lg " id="calculate">Calculate</button> 
</div>
</div>


    <div class="form-group">
    <h4><label class="control-label col-sm-4" for="amount"><b>Amount:</b></label></h4>
    <div class="col-sm-8">
    <input type="text" class="form-control" id="amount" name="amount" >
    </div><br><br><br>
    </div>

    
     <div class="form-group">
      <div class=" col-sm-4"> 
           
      </div>      
      <div class="col-sm-8">
      
      <div class="col-sm-4">
      <button type=button class="btn btn-Info btn-lg" id="save" ><b>Save</b></button>
      </div>      
      <div class="col-sm-4">
      <button type=submit class="btn btn-Info btn-lg" id="print"><b>Print</b></button>
      </div>
      <div class="col-sm-4">
      <button type=button class="btn btn-Info btn-lg" id="exit"><b>Exit</b></button> 
      </div>
      </div>
      </div>

</FORM>

<DIV class="COL-SM-3"><br><br><br><br>
</DIV>
</div>
</div>
</body>
</html>