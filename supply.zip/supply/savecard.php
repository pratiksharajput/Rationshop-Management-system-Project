<?php
   $name=$_GET['name'];
   $address=$_GET['address'];
   $cntno=$_GET['cntno'];
   $idate=$_GET['idate'];
   $ctype=$_GET['ctype'];
   $cno=$_GET['cno'];
   $occuption=$_GET['occuption'];
   
   $con=mysql_connect("localhost","root","");
   mysql_select_db("rationshop",$con);
   $sql="insert into cardregister values('$name','$address','$cntno','$idate','$ctype','$cno','$occuption')";
   $result=mysql_query($sql);
if($result==1)
   echo "Record is Saved";
else
echo "Record is not Saved";
?>   
