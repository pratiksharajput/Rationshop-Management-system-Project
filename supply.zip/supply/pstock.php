<html>
<head>
       <link rel="stylesheet" href="./css/bootstrap.css">
       <script type="text/javascript" src="./js/jquery.js"></script>
       <script type="text/javascript" src="./js/bootstrap.min.js"></script>  
         <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>Ration Shop Management System</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
        
    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]--> 
       <script type="text/javascript">
          $(document).ready(function () {
            $("#exit").click(function () {
                 window.location="demo.php";
           });
          });
       </script>
       <script type="text/javascript">
          $(document).ready(function () {
            $("#save").click(function () {
               var month = $("#month").val();
               var date=$("#date").val();
               var wheat=$("#wheat").val();
               var rice=$("#rice").val();
               var sugar=$("#sugar").val();
               var oil=$("#oil").val();
               var kerosene=$("#kerosene").val();
               var data1="month="+month+"&date="+date+"&wheat="+wheat+"&rice="+rice+"&sugar="+sugar+"&oil="+oil+"&kerosene="+kerosene;
               var flag=0; 
       if (month == '') 
       {
         alert("Month should not empty");
         flag=1;
         $("#month").focus();  
       }
       if (date== '') 
       {
         alert("Date should not empty");
         flag=1;
         $("#date").focus();  
       }
       
        
       if(flag==0)
        {
               $.ajax({
                            url:"savestock.php",
                            data:data1,
                            success: function(result){
                                alert(result);
                              $("#month").val("");
                              $("#date").val("");
                              $("#wheat").val("");
                              $("#rice").val("");
                              $("#sugar").val("");
                              $("#oil").val("");
                              $("#kerosene").val("");

                            } 
              });
         }
            });
         });
       </script>
    </head>

<BODY >
<!--header start-->
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <!--logo start-->
            <a class="logo"><font color=black><b>Provided Stock</b></a>
            <!--logo end-->
            
            <div class="top-menu">
               <br>
            	<ul class="nav pull-right top-menu">
                    <li><a class="home" href="demo.php">Home</a></li>
            	</ul>
            </div>
        </header>
      <!--header end--><br>

<!--......Delete form...-->

<DIV class="container">
<DIV class="row">
<DIV class="COL-SM-3">
</div>


<DIV CLASS="COL-SM-6"><font color=black>
<BR><BR>
<FORM class="form-horizontal" role="form">
        
     <div class="form-group">
    <div class="col-sm-4"></div>
    <div class="col-sm-8">
    
    </div><br><br><br>
    </div>
    

    <div class="form-group">
     <h4> <label class="control-label  col-sm-4" for="month">Month:-</label></h4>
      <div class="col-sm-8">
       <select name="month" class="form-control" id="month">
       <option value=1>January</option>
       <option value=2>February</option>
       <option value=3>March</option>
       <option value=4>April</option>
       <option value=5>May</option>
       <option value=6>June</option>
       <option value=7>July</option>
       <option value=8>August</option>
       <option value=9>september</option>
       <option value=10>October</option>
       <option value=11>November</option>
       <option value=12>December</option>
      </select>
      </div>
      </div>
    <div class="form-group">
    <h4><label class="control-label col-sm-4" for="date">Date:</label></h4>
    <div class="col-sm-8">
    <input type="date" class="form-control" id="date" >
    </div><br><br><br>
    </div>
  
    <div class="form-group">
    <div class="col-sm-1">
     </div>
    <div class="col-sm-11">  
    <h3 style="color:MediumVioletRed;text-align:center"><b>Product Name:</b></h3>
    </div>
    </div>
    
   

    <div class="form-group">
    <h4><label class="control-label col-sm-4" for="wheat">Wheat:</label>
    <div class="col-sm-8">
    <input type="text" class="form-control" placeholder="kg" id="wheat" ><h4>
    </div><br><br><br>
    </div>
    
    <div class="form-group">
    <h4><label class="control-label col-sm-4" for="rice">Rice:</label>
    <div class="col-sm-8">
    <input type="text" class="form-control" placeholder="kg" id="rice"><h4>
    </div><br><br><br>
    </div>
 
     <div class="form-group">
    <h4><label class="control-label col-sm-4" for="sugar">Sugar:</label>
    <div class="col-sm-8">
    <input type="text" class="form-control" placeholder="kg" id="sugar"><h4>
    </div><br><br><br>
    </div>


     <div class="form-group">
    <h4><label class="control-label col-sm-4" for="oil">Oil:</label>
    <div class="col-sm-8">
    <input type="text" class="form-control" placeholder="lit" id="oil"><h4>
    </div><br><br><br>
    </div>


     <div class="form-group">
    <h4><label class="control-label col-sm-4" for="kerosene">Kerosene:</label>
    <div class="col-sm-8">
    <input type="text" class="form-control" placeholder="lit" id="kerosene"><h4>
    </div><br><br><br>
    </div>



    <div class="form-group">
      <div class="col-sm-4">         
      </div>
      
      <div class="col-sm-8">
      
      <div class="col-sm-6">
      <h1><button type=button class="btn btn-Info btn-lg" id="save" >Save</button></h1>
      </div>      
      <div class="col-sm-6">
      <h1><button type=button class="btn btn-Info btn-lg" id="exit" >Exit</button></h1>
      </div>
      </div>
      
</div>
</FORM>
</DIV>
<DIV class="COL-SM-3">
</DIV>
</div>
</div>
</body>
</html>
