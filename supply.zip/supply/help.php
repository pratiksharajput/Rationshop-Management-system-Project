<html>
<head>
<center><h1 style="color:MediumVioletRed"><b>Help</b></h1></center>
</head>
<body>

<img src="./screenshot/index.png"><br><br>

<p>
   This window helps admin to log into the system ; When the valid 
   user name and password is entered and click on Login button .
   
   By clicking on user Login button user will be able to access
   the system using valid username and password provided by admin.
   
   Iff the username or password entered are wrong then it show 
   message at bottom as "Invalid Credentials".
</p>
<img src="./screenshot/userlogin.png"><br><br>

<p>
   Valid user is able to log into system by entering user name and 
   password and click on log in button.
    
   Exit button helps exit the system.
</p>
 
<img src="./screenshot/home.png"><br><br>  

<p>
   From the home page admin is able to access entire system .
   
   On the side bar all provisions are provided under TASKS,
   REPORT,SETTING,LICENSE.
 
   Log out button on the upper right corner helps to exit the system.
</p>

<img src="./screenshot/home.png"><br><br>  

 </body>
<html> 
