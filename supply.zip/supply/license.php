<html>
<head>
       <link rel="stylesheet" href="./css/bootstrap.css">
       <script type="text/javascript" src="./js/jquery.js"></script>
       <script type="text/javascript" src="./js/bootstrap.min.js"></script>  
        
        
    </head>

<BODY >

<DIV class="container">
<DIV class="row">



<DIV class="COL-SM-3">
<img src="./images/duplicate.jpg" class="img-responsive" width="450" height="300"><br><br>

</div>

<DIV class="COL-SM-3">
<img src="./images/certificate.jpg" class="img-responsive" width="400" height="300"><br><br>

</DIV>

<DIV CLASS="COL-SM-3" >
<img src="./images/renew.jpg" class="img-responsive" width="400" height="300"><br><br>
</div>


<DIV CLASS="COL-SM-3" >
<img src="./images/l4.jpg" class="img-responsive" width="400" height="300"><br><br>


</div>

</div>
</div>
</body>
</html>


