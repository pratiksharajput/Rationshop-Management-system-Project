<html>
<head>
 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>Ration Shop Management System</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
        
    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]--> 

</head>
<body >
<!--header start-->
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <!--logo start-->
            <a class="logo"><font color=black><b>Customer's Monthly Report</b></a>
            <!--logo end-->
            
            <div class="top-menu">
               <br>
            	<ul class="nav pull-right top-menu">
                    <li><a class="home" href="demo.php">Home</a></li>
            	</ul>
            </div>
        </header><br><br><br><br><br><br><br><br>
      <!--header end-->



<?php
  $m=$_GET['month'];
  mysql_connect("localhost","root","");
  mysql_select_db("rationshop");
  $sql="select * from dailyrecord where month(date)='".$m."'";
  $res=mysql_query($sql);
    echo "<center><table   style='text-align:center;background-color:white' border=3 width=600 height=150><tr><th style=color:MediumVioletRed>Card No</th><th style=color:MediumVioletRed>Name</th><th style=color:MediumVioletRed>Date</th><th style=color:MediumVioletRed>Wheat</th><th style=color:MediumVioletRed>Sugar</th><th style=color:MediumVioletRed>Rice</th><th style=color:MediumVioletRed>Oil</th><th style=color:MediumVioletRed>Kerosene</th></tr>";
  while($row=mysql_fetch_array($res))
  {
    echo "<tr>";
      echo "<td>".$row['cno']."</td>";
      echo "<td>".$row['name']."</td>";
      echo "<td>".$row['date']."</td>";
      echo "<td>".$row['wheat']."</td>";
      echo "<td>".$row['sugar']."</td>";
      echo "<td>".$row['rice']."</td>";
      echo "<td>".$row['oil']."</td>";
      echo "<td>".$row['kerosene']."</td>";
    echo "</tr>";
  }
  echo "</table></center>";

  mysql_close();
 ?>
</body>
</html>
   
 
