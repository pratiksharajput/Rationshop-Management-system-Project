<?php
$var=$_GET['r1'];

if(trim($var)=='Daily')
{

header('Location:dailycust.php');
}

if($var=='Monthly')
{
header('Location:monthlycust.php');
}
?>