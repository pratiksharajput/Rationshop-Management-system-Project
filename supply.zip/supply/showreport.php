<?php
$var=$_GET['r1'];

if(trim($var)=='Daily')
{

header('Location:daily.php');
}

if($var=='Monthly')
{
header('Location:monthly.php');
}
?>