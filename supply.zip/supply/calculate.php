<?php 
   
   $wheat=$_GET['wheat'];
   $rice=$_GET['rice'];
   $sugar=$_GET['sugar'];
   $oil=$_GET['oil'];
   $kerosene=$_GET['kerosene'];
   $amt=$wheat*4+$rice*4+$sugar*4+$oil*5+$kerosene*5;
    echo $amt;

?>   
