<?php
   $name=$_GET['name'];
   
   $cno=$_GET['cno'];
   
   
   $con=mysql_connect("localhost","root","");
   mysql_select_db("rationshop",$con);
   $sql="delete from cardregister where name='$name' and cno='$cno'";
   $result=mysql_query($sql);

   echo "Record is Deleted";

?>   
