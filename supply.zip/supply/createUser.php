<html>
<head>
       <link rel="stylesheet" href="./css/bootstrap.css">
       <script type="text/javascript" src="./js/jquery.js"></script>
       <script type="text/javascript" src="./js/bootstrap.min.js"></script> 

 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>Ration Shop Management System</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
        
    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]--> 
 
       <script type="text/javascript">
          $(document).ready(function () {
            $("#exit").click(function () {
                 window.location="demo.php";
           });
          });
       </script>
       <script type="text/javascript">
          $(document).ready(function () {
            $("#create").click(function () {
               var name = $("#name").val();
               var address=$("#address").val();
               var cntno=$("#cntno").val();
               var uname=$("#uname").val();
               var passw=$("#passw").val();
               var data1="&name="+name+"&address="+address+"&cntno="+cntno+"&uname="+uname+"&passw="+passw;
               var flag=0; 
       if (name == '') 
       {
         alert("Name should not empty");
         flag=1;
         $("#name").focus();  
       }
       if (address== '') 
       {
         alert("Address should not empty");
         flag=1;
         $("#address").focus();  
       }
       if (cntno== '') 
       {
         alert("Contact no should not empty");
         flag=1;
         $("#cntno").focus();  
       }
       if (uname== '') 
       {
         alert("User name should not empty");
         flag=1;
         $("#uname").focus();  
       }
       if (passw== '') 
       {
        alert("Password should not empty");
         flag=1;
         $("#passw").focus();  
       }
        
       if(flag==0)
        {
               
               $.ajax({
                            url:"saveuser.php",
                            data:data1,
                            success: function(result){
                                alert(result);
                              $("#name").val("");
                              $("#address").val("");
                              $("#cntno").val("");
                              $("#uname").val("");
                              $("#passw").val("");
                              
                            } 
              });
         }
           });
         
         });
       </script>
    </head>
<BODY >

<!--header start-->
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <!--logo start-->
            <a class="logo"><font color=black><b>Create User</b></a>
            <!--logo end-->
            
            <div class="top-menu">
               <br>
            	<ul class="nav pull-right top-menu">
                    <li><a class="home" href="demo.php">Home</a></li>
            	</ul>
            </div>
        </header><br><br><br><br><br><br>
      <!--header end-->

<DIV class="container">

<DIV class="row">
<DIV class="COL-SM-3">
</DIV>

<DIV class="COL-SM-6"><font color=Black><br><br>

<FORM class="form-horizontal" role="form">

         
      <div class="form-group">
      <div class="col-sm-2">         
      </div>
      <div class="col-sm-10">
      
      </div>   
      </div>
      <div class="form-group">
      <h4><label class="control-label col-sm-4" for="Name">Name:-</label></h4>
      <div class="col-sm-8">
      <input type="text" class="form-control" id="name">
      </div>
      </div><br>
      
      <div class="form-group">
       <h4><label class="control-label col-sm-4 " for="add">Address:-</label></h4>
      <div class="col-sm-8">
      <TEXTAREA width=300 height=400 name=Address class="form-control" id="address" ></TEXTAREA>
      </div>
      </div><br>

      <div class="form-group">
      <h4><label class="control-label col-sm-4" for="Cno">Contact No:-</label></h4>
       <div class="col-sm-8">
      <input type="text" class="form-control" id="cntno">
      </div>
      </div><br>
       
      <div class="form-group">
      <h4><label class="control-label  col-sm-4" for="uname">User Name:-</label></h4>
      <div class="col-sm-8">
       <input type="text" class="form-control" id="uname">
      </div>
      </div><br>
      

       <div class="form-group">
      <h4><label class="control-label  col-sm-4" for="passw">Password:-</label></h4>
      <div class="col-sm-8">
       <input type="password" class="form-control" id="passw">
      </div>
      </div><br>
      

      <div class="form-group">
      <div class="col-sm-4">         
      </div>
      
      <div class="col-sm-8">
      
      <div class="col-sm-6">
      <button type=button class="btn btn-Info btn-lg btn-block " id="create"><b>Create</b></button>
      </div>      
      <div class="col-sm-6">
      <button type=button class="btn btn-Info btn-lg btn-block" id="exit"><b>Exit</b></button>
      </div>
      </div>
<br><br><br><br>      
</div>
</div>     
</FORM>
</DIV>

<DIV class="COL-SM-3">
</DIV>

</DIV>
</DIV>
</body>
</html>
