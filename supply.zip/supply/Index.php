<html>
    <head>
       <link rel="stylesheet" href="./css/bootstrap.css">
       <script type="text/javascript" src="./js/jquery.js"></script>
       <script type="text/javascript">
          $(document).ready(function () {
            $("#userlogin").click(function () {
                 window.location="userlogin.php";
           });
          });
       </script>
       <script type="text/javascript">
          $(document).ready(function () {
            $("#login").click(function () {
               var uname = $("#uname").val();
               var passw=$("#passw").val();
               
                if (uname == 'rshop') {
                  $("#availability").html("");
                }
             else{
                      $.ajax({
                                    url: "login.php?uname="+uname+"&passw="+passw
                                }).done(function( data ) {
                         if(data==1)
                         {
                           $( location ).attr("href", "http://localhost/supply/demo.php");
                         }
                         else
                           $("#availability").html(data);
                });   
              } 
            });
          });
       </script>
    </head>
    <body background="./images/dark2.jpg">
<DIV class="container">
<div class="row"><BR><BR><BR>
<center><h1 style="color:white"><b>Ration Shop Management System</b></h1></center><BR><BR><BR><BR>



<DIV class="COL-SM-4">

</DIV>

 <div class="col-sm-4" style="background-color:white; border-radius:10px">
     <h2 align=center><span class="glyphicon glyphicon-user"></span> Login</h2>
     <input type=text class="form-control" placeholder="User Name" id="uname"><br>
     <input type=password class="form-control" placeholder="Password" id="passw"><br><br>
     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type=button class="btn btn-lg btn-Info" value="Login" id="login">
     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type=button class="btn btn-lg btn-Info" value="User Login" id="userlogin">

   &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href="help.php"><center><h4 style="text-align:center;color:red" label class="control-label col-sm-10" for="Help">Help</a></h4></center></label>
     
 
<br><br><br><div id="availability" align="center"><font color=red></font></div>
</DIV>

</div>


<DIV class=" COL-SM-4">

</DIV>
</DIV>


</body>
</html>
         