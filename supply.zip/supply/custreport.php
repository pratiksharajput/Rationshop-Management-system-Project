<HTML>
<HEAD>
<link rel="stylesheet" href="./css/bootstrap.min.css">
  <script src="./js/jquery.js"></script>
  <script src="./js/bootstrap.min.js"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>Ration Shop Management System</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
        
    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
 </HEAD>
<BODY>

<!--header start-->
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <!--logo start-->
            <a class="logo"><font color=black><b> Report</b></a>
            <!--logo end-->
            
            <div class="top-menu">
               <br>
            	<ul class="nav pull-right top-menu">
                    <li><a class="home" href="demo.php">Home</a></li>
            	</ul>
            </div>
        </header><br><br><br><br><br><br>
      <!--header end-->
      <form  method="GET" action="custreportnext.php" class="form-horizontal" role="form">
<DIV class="container">

<DIV class="row">
<DIV class="COL-SM-3">
</DIV>
<DIV class="COL-SM-6"><font color=black><br><br>
          

      <DIV class="COL-SM-4">
      </DIV>
      <div class="form-group">
      <DIV class="COL-SM-4">
       
       &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<h4><b><input type=radio  value="Daily" name="r1">Daily</b></h4><br>
        
        &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<h4><b><input type=radio  value="Monthly"name="r1">Monthly</b></h4><br>

        <h1><button type="submit" class="btn btn-Info btn-lg ">Show</button></h1>
      
        </DIV>
        </div>
       <DIV class="COL-SM-4"></DIV>
       </DIV>
<DIV class="COL-SM-3">
</DIV>
</form>
</body>
</html>