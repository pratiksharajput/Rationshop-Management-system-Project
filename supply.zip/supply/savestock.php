<?php
   $month=$_GET['month'];
   $date=$_GET['date'];
   $wheat=$_GET['wheat'];
   $rice=$_GET['rice'];
   $sugar=$_GET['sugar'];
   $oil=$_GET['oil'];
   $kerosene=$_GET['kerosene'];
   
   $con=mysql_connect("localhost","root","");
   mysql_select_db("rationshop",$con);
   $sql="insert into providedstock values('$month','$date','$wheat','$rice','$sugar','$oil','$kerosene')";
   $result=mysql_query($sql);

   echo "Record is Saved";

?>   
