<html>
    <head>
       <link rel="stylesheet" href="./css/bootstrap.css">
       <script type="text/javascript" src="./js/jquery.js"></script>
        <script type="text/javascript">
          $(document).ready(function () {
            $("#exit").click(function () {
                 window.location="index.php";
           });
          });
       </script>
       <script type="text/javascript">
  $(document).ready(function () {

    $("#login").click(function () {
      var uname = $("#uname").val();
      var passw=$("#passw").val();
      if (uname == '') {
        $("#availability").html("");
      }
      else{
        $.ajax({
          url: "login1.php?uname="+uname+"&passw="+passw
        }).done(function( data ) {
          $("#availability").html(data);
          if(data==1)
           $( location ).attr("href", "http://localhost/supply/searchr2.php");
        });   
      } 
    });
  });
</script>

    </head>
    <body background="./images/dark2.jpg">
<DIV class="container">
<div class="row"><BR><BR><BR>
<center><h1 style="color:white"><b>User Login</b></h1></center><BR><BR><BR><BR>

<DIV class="COL-SM-4">

</DIV>

 <div class="col-sm-4" style="background-color:white; border-radius:10px">
     <h2 align=center><span class="glyphicon glyphicon-user"></span> Login</h2><br>
     <input type=text class="form-control" placeholder="User Name" id="uname"><br><br>
      <input type=password class="form-control" placeholder="Password" id="passw"><br><br>
    
<div class="form-group">
      <div class="col-sm-1">         
      </div>
      
      <div class="col-sm-10">
      
      <div class="col-sm-6">
      <button type=button class="btn btn-Info btn-lg btn-block " id="login"><b>Log In</b></button>
      </div>      
      <div class="col-sm-6">
      <button type=button class="btn btn-Info btn-lg btn-block" id="exit"><b>Exit</b></button>
      </div>
<br><br>
<br><br><div id="availability" align="center"><font color=red></font></div>
</div>
</div>

<DIV class=" COL-SM-1">

</DIV>
</DIV>


</body>
</html>
         