<html>
    <head>
       <link rel="stylesheet" href="./css/bootstrap.css">
       <script type="text/javascript" src="./js/jquery.js"></script>
       <script type="text/javascript" src="./js/bootstrap.min.js"></script>  
       <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>Ration Shop Management System</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
        
    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]--> 

    </head>
    <body >
<form  method=GET action="akerosene1.php" class="form-horizontal" role="form">
<DIV class="container">
<div class="row">

<!--header start-->
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <!--logo start-->
            <a class="logo"><font color=black><b>Available Kerosene</b></a>
            <!--logo end-->
            
            <div class="top-menu">
               <br>
            	<ul class="nav pull-right top-menu">
                    <li><a class="home" href="demo.php">Home</a></li>
            	</ul>
            </div>
        </header><br><br><br><br><br><br>
      <!--header end-->

<DIV class="COL-SM-4">

</DIV>

 <div class="col-sm-4" style="background-color:whitesmoke; border-radius:10px"> 
     <div class="form-group"><br><br>
    
      <label class="control-label  col-sm-4" for="month">Select Month:-</label>
      <div class="col-sm-8">
       <select name="month" class="form-control" id="month">
       <option value=1>January</option>
       <option value=2>February</option>
       <option value=3>March</option>
       <option value=4>April</option>
       <option value=5>May</option>
       <option value=6>June</option>
       <option value=7>July</option>
       <option value=8>August</option>
       <option value=9>september</option>
       <option value=10>October</option>
       <option value=11>November</option>
       <option value=12>December</option>
      </select>
      </div>
      </div>
      
     <center><input type=submit class="btn btn-lg btn-Info" name="Submit"></center><br><br>
</div>
</div>


<DIV class=" COL-SM-4">

</DIV>
</DIV>


</body>
</html>
         