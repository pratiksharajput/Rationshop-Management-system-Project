<?php
$var=$_GET['r1'];

if($var=='wheat')
{

header('Location:awheat.php');
}

if($var=='rice')
{
header('Location:arice.php');
}
if($var=='sugar')
{
header('Location:asugar.php');
}
if($var=='oil')
{
header('Location:aoil.php');
}
if($var=='kerosene')
{
header('Location:akerosene.php');
}
?>