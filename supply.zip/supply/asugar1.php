<html>
<head>
 
       <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>Ration Shop Management System</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
        
    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]--> 
</head>
<body >
<!--header start-->
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <!--logo start-->
            <a class="logo"><font color=black><b>Available Sugar</b></a>
            <!--logo end-->
            
            <div class="top-menu">
               <br>
            	<ul class="nav pull-right top-menu">
                    <li><a class="home" href="demo.php">Home</a></li>
            	</ul>
            </div>
        </header><br><br><br><br><br><br>
      <!--header end-->

<?php
    $m=$_GET['month'];
    $con=mysql_connect("localhost","root","");
    mysql_select_db("rationshop",$con);
    $sql1="select * from providedstock where month(date)='".$m."'";
    $result1=mysql_query($sql1);
    while($row1=mysql_fetch_array($result1)) 
    {
       $sugar=$row1['sugar'];
      
    }
     $sum=0;
      $sql2="select * from dailyrecord where month(date)='".$m."'";
      $result2=mysql_query($sql2);
      while($row2=mysql_fetch_array($result2))
      {
        $sum=$sum+$row2['sugar'];
      }
      
    $stock=$sugar-$sum;

  echo "<center><table   style='text-align:center;background-color:white' border=3 width=600 height=150><tr><th style=color:MediumVioletRed>Month</th><th style=color:MediumVioletRed>Item Name</th><th style=color:MediumVioletRed>Provided Quantity</th><th style=color:MediumVioletRed>Selling Quantity</th><th style=color:MediumVioletRed>Available </th></tr>";
  
    echo "<tr>";
    
      echo "<td>$m</td>";
      echo "<td>Sugar</td>";
      echo "<td>$sugar</td>";
      echo "<td>$sum</td>";
      echo "<td>$stock</td>";
    echo "</tr>";
 
  echo "</table></center>";
?>
