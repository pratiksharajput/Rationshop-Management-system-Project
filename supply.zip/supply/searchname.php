<?php
   $cno=$_GET['cno'];
   $con=mysql_connect("localhost","root","");
   mysql_select_db("rationshop",$con);
   $sql="select name from cardregister where cno='$cno'"; 
   $result=mysql_query($sql);
   while($row=mysql_fetch_array($result))
{
  echo $row['name'];
}
   
?>   
 