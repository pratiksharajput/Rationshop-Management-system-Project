<?php 
   $cno=$_GET['cno'];
   $name=$_GET['name'];
   $date=$_GET['date'];
   $wheat=$_GET['wheat'];
   $rice=$_GET['rice'];
   $sugar=$_GET['sugar'];
   $oil=$_GET['oil'];
   $kerosene=$_GET['kerosene'];
   
   $con=mysql_connect("localhost","root","");
   mysql_select_db("rationshop",$con);
   $sql="insert into dailyrecord values('$cno','$name','$date','$wheat','$rice','$sugar','$oil','$kerosene')";
   $result=mysql_query($sql);
    if($result==1)
   echo "Record is Saved";
 else
 echo "Record not save";

?>   
