<html>
<head>
<link rel="stylesheet" href="./css/bootstrap.min.css">
  <script src="./js/jquery.js"></script>
  <script src="./js/bootstrap.min.js"></script>
</head>
<body>
<DIV class="container">
<DIV class="row">
<DIV class="COL-SM-3">
</div>
<DIV class="COL-SM-6"><br><br>
<div style="border-style:solid; color:black ;padding-right:30px"> <br>  
<?php
   $cno=$_GET['cno'];
   $name=$_GET['name'];
   $date=$_GET['date'];
   $wheat=$_GET['wheat'];
   $rice=$_GET['rice'];
   $sugar=$_GET['sugar'];
   $oil=$_GET['oil'];
   $kerosene=$_GET['kerosene'];
   $amount=$_GET['amount'];
   $w=2*$wheat;
   $r=3*$rice;
   $s=4*$sugar;
   $o=20*$oil;
   $k=10*$kerosene;
   $u=$wheat+$rice+$sugar+$oil+$kerosene;
 
echo "<br>";
echo "<center>Card No:$cno</center>";
echo "<br>";
echo " <center>Shop Name:-Gulshan Mahila Bachat Gat</center>";
echo "<br>";
echo " <center>Name:-$name</center>";
echo "<br>";
echo "<center>Ration Shop No:115  ,Malegaon</center>";
echo "<br>";
echo "<center><table   style='text-align:center;background-color:white' border=3 width=300 height=300><tr><th><b>Type</b></th><th><b>Rate</b></th><th><b>Weight</b></th><th><b>Rupees</b></th>";
echo"<tr><td>Wheat</td><td>2</td><td>$wheat</td><td>$w</td></tr>";
echo"<tr><td>Rice</td><td>3</td><td>$rice</td><td>$r</td></tr>";
echo"<tr><td>Sugar</td><td>4</td><td>$sugar</td><td>$s</td></tr>";
echo"<tr><td>oil</td><td>20</td><td>$oil</td><td>$o</td></tr>";
echo"<tr><td>Kerosene</td><td>10</td><td>$kerosene</td><td>$k</td></tr>";
echo"<tr><td><b>Unit</b></td><td>-</td><td>$u</td><td>$amount</td></tr>";
echo "</table>";
echo "<br>";
echo "Date:- $date ";
echo "<br><br>";
echo "Sign:-";
echo "<br><br>";
?>
</div>
</div>
<DIV class="COL-SM-3">
</div>
</body>
</html>
