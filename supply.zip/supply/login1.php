<?php  //Start the Session
session_start();
 $link = mysql_connect('localhost', 'root', '');
 mysql_select_db('rationshop', $link);
 if (isset($_GET['uname']) and isset($_GET['passw']))
{
  $uname = $_GET['uname'];
  $passw = $_GET['passw'];
  $query = "SELECT * FROM createuser WHERE uname='$uname' and passw='$passw'";
  $result = mysql_query($query) or die(mysql_error());
   $count = mysql_num_rows($result);
   if ($count == 1)
   {
      $_SESSION['uname'] = $uname;
      echo "1"  ;  
   }
  else
   {
     echo "<font color=red>Invalid Login Credentials.</font>";
  }
}
?>    